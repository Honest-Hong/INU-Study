import tkinter
import requests
import bs4
from collections import Counter
from konlpy.tag import Twitter

def Search(keyword):
    allText = ""
    for page in range(1,6):
        url = 'http://www.koreaherald.com/search/?q=' + keyword + '&dt=2&nt=1&np=' + str(page) + '&hq='
        soup = bs4.BeautifulSoup(requests.get(url).text, 'html.parser', from_encoding='utf-8')
        container = soup.body.find(id='container')
        dd = container.div.findAll('dd')


        for i in range(10):
            try:
                aList = dd[i].findAll('a')
                if len(aList) >= 2:
                    print('제목: ', aList[1].text)
                else:
                    print('제목: ', aList[0].text)
                print(aList[0]['href'])
                soup2 = bs4.BeautifulSoup(requests.get(aList[0]['href']).text, 'html.parser', from_encoding='utf-8')
                article = soup2.body.find(id='articleText')
                try:
                    allText += article.text
                except:
                    print('사이트가 다름')
                    continue
            except:
                print('기사 없음')
                break

    h = Twitter()
    temp = h.nouns(allText)
    nouns = []
    for t in temp:
        if len(t) > 1:
            nouns.append(t)
    count = Counter(nouns)
    print(count.most_common(100))

def KeyEvent(event):
    global ent
    Search(ent.get())

window = tkinter.Tk()
window.title('기사 모음')
window.geometry('300x100')
lbl = tkinter.Label(window, text='검색 키워드')
ent = tkinter.Entry(window)
ent.bind('<KeyRelease-Return>', KeyEvent)
btn = tkinter.Button(window, text='검색 시작', command= lambda : Search(ent.get()))
lbl.pack()
ent.pack()
btn.pack()
window.mainloop()
