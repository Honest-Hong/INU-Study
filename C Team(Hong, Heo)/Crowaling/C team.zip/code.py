import requests
import bs4

keyword = '%ED%99%8D%EC%A4%80%ED%91%9C'
url = 'http://www.koreaherald.com/search/?q=%EB%AC%B8%EC%9E%AC%EC%9D%B8&dt=2&nt=1&np=1&hq='
soup = bs4.BeautifulSoup(requests.get(url).text, 'html.parser', from_encoding='utf-8')
container = soup.body.find(id='container')
dd = container.div.findAll('dd')
for i in range(10):
    aList = dd[i].findAll('a')
    if len(aList) >= 2:
        print('제목: ', aList[1].text)
    else:
        print('제목: ', aList[0].text)
    soup2 = bs4.BeautifulSoup(requests.get(aList[0]['href']).text, 'html.parser', from_encoding='utf-8')
    article = soup2.body.find(id='articleText')
    print(article.text)
